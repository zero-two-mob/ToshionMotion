# TOSHION MOTION

A native Android video editor, built in phases toward Alight Motion–level
workflow: layer-based timeline, GPU-accelerated preview, keyframe animation,
a modular effects engine, and hardware-accelerated multi-codec export.

Package: `com.toshion.motion` (fully renamed — package declarations,
imports, folder structure, Gradle `namespace`/`applicationId` all match).
Internal class names that happen to contain "MotionForge" (e.g.
`MotionForgeApplication`, `MotionForgeDatabase`) were deliberately left
as-is — they're invisible implementation details, not part of the app's
identity, and renaming them is pure churn for zero benefit. The on-disk
database file is `toshion_motion.db`.

**Practical note on installing over a previous build:** if you still have
an APK installed from an earlier build under a different package name
(`com.motionforge.editor`), that's a genuinely different app to Android —
this one won't update over it, they'd coexist. If you'd previously
installed something built with the *same* package name from a different
source (e.g. a different build tool), you may need to uninstall that one
first — debug builds from different environments normally have different
signing keys, and Android blocks installing a same-package app over one
signed differently.

## Status: Phase 4 (Timeline System) built

Same content as the last handoff — this pass was the package rename, no
feature changes. See below for what Phase 4 actually built.

**Built for real:**
- `Clip` domain model + Room table + repository + 5 use cases (Get/Add/
  Trim/Split/Delete), Clean-Architecture-consistent with everything else
- Multi-clip ExoPlayer playlist — each clip becomes a `MediaItem` with its
  own `ClippingConfiguration`, so per-clip in/out trimming actually plays
  back correctly, not just visually
- Global timeline position tracking across clip boundaries
- Timeline UI: ruler, zoom (+/- buttons), horizontal scroll, tap a clip to
  select it, tap empty timeline to seek, drag handles to trim (commits
  once on release, not per-frame)
- Add Clip (Photo Picker), Split at playhead, Ripple delete
- Gapless single-track model — clips always sit back-to-back, which is
  what gives "nothing can create a gap" for free
- Creating a project drops you straight into the Editor with your picked
  media already seeded as the first clip

**Deliberately not built:** multi-select, drag-to-reorder, groups/nested
groups, layer collapse/expand, layer colors, timeline markers — these need
actual multi-track layer types (Phase 5) to be meaningful. Pinch-to-zoom
was considered and dropped for +/- buttons — avoids real gesture-conflict
risk with the scrollable container that I can't test my way out of.

## Building

Two files, same as always: **Add file → Upload files** with this zip
(now named `ToshionMotion.zip`, matches the workflow below), then
**Add file → Create new file** at `.github/workflows/android-build.yml`
with the workflow content. Actions tab builds it, grab the APK from the
finished run's artifacts.

## Next up

Phase 5: the Layer Engine — video/image/audio/text/shape/adjustment/mask
layer types, multi-track support, opacity/blend modes/transforms.
